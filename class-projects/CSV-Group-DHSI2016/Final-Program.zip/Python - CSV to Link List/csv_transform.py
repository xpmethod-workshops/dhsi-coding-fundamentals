# This program will read iteratively over rows in a .csv file outputting a reformatted 
# .csv that indicates relationship links between agents in shared rows. It takes a structured
# table and builds an edge list on the basis of shared row.

# ToDo - account for exceptions:
#     Sellers do not know other Sellers
#     Illustrators do not know Sellers
#     Engravers to not know Sellers
#     Editors do not know Translators

#     Get rid of double spacing csv

#     append booktitle to each csv row entry

import csv                                       # import the csv library
import sys
import codecs

readCells = [7,8,9,10,11,12,13,15,17,19,20,      # Use this constant called 'readCells' as a map for reading 'converted'
21,22,23,24,25,28,31,34,37,40,43,46,49,52,       # These are the columns with agents in them (in my case, people and books)
55,58,61,64,67,70,73,76,79]


with open("original_csv.csv", "r") as f:         # open and read the original csv file and assign it to a variable (f) that we can do things to.
    converted = csv.reader(f)                    # with a csv(f), read it in the csv.reader manner and drop that reading into a container called 'converted'
    next(converted)                              # process every other line, skipping the header line (this is here because my csv is double spaced for some reason) 

    for book in converted:                       # for each row (book) in the table 'converted'...
        book = next(converted)                   # go to the next row (this ensures the return iterates on the next line)
        pairsdictionary = { }                    # pairs we find in the loop will be output to this dictionary
        booktitle = book[5]                      # the booktitle is always in the 5th position (I want the output to list the book that relationships are associated with--this provides that)
        source = 0                               # the source begins at position 0 (which is column 7 in readCells list)
        target = 1                               # the target begins at position 1 (which is column 8 in readCells list--the point is that I don't want self-loops)
        readCellLen = len(readCells)             # the length of the readCells list is len(readCells)--establishes a measure for the loop to approximate closure
        
        while source < len(readCells) -1:        # while the position of the source agent we are on is less than the total length of the list - 1
            if book[readCells[source]] != '':        # and if the source value is not empty (if the cell it is reading has a value)
                while target <= len(readCells) -1:        # and while the target cell is less than or equal to the total length of the list
                    if book[readCells[target]] != '':          # and if the target cell is not empty
                        pairsdictionary[book[readCells[source]]]=book[readCells[target]]
                        pairsdictionary[book[readCells[target]]]=book[readCells[source]]
                    target += 1                  # reset target to original target [] plus 1--bring the cell iteration back to source+1 before we reset the whole thing
            source += 1                          # reset source to original source [] plus 1 } prep for reiteration
            target = source + 1                  # reset target to original target [] plus 1 } prep for reiteration
            
        for entry in pairsdictionary:                                # for each entry in the dictionary
        	#print(entry,",",pairsdictionary[entry],",",booktitle)
            #print(pairsdictionary)
            with open("new_csv.csv", "a") as f:                      # open this new csv file in the append mode and call it variable f
                w = csv.writer(f)                                    # pass f to the csv writer method and place all that in the container w
                w.writerows(pairsdictionary.items())                 # write rows to the csv f that include the dictionary items
                